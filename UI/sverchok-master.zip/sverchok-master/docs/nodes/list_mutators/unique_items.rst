Unique Items
============

Returns unique elements of an list. (sorted if possible)

Outputs
-------

**Items**: Unique elements of an list

**Indices**: The indices of the input array that give the unique values

**Inverse Indices**: The indices of the unique array that reconstruct the input array

**Counts**: The number of times each unique value comes up in the input array

Example
-------

.. image:: https://user-images.githubusercontent.com/10011941/102199566-10205a80-3ec4-11eb-9cda-fe3ad1938290.png
