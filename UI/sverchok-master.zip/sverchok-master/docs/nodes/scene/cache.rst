cache
=====

You can set the data stored in this node, and output it with an offset using **cache_offset** which will return the data stored for the frame at `frame_current-cache_offset`.

it's a very simple node, you should look at the implementation.