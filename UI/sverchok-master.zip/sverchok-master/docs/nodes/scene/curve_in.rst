curve in
========

pick a curve from the scene, and output it into the nodetree, with additional options to apply smoothing. and reading radii for each of its points.

Best to read the development thread 

https://github.com/nortikin/sverchok/issues/1817
https://github.com/nortikin/sverchok/pull/1818
