cricket
=======

mascot node, outputs verts and faces only. You can set the scale of the object.