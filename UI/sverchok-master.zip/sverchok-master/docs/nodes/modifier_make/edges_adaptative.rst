Adaptative Edges
================