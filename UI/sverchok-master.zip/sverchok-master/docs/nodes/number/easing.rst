easing
======

This node offers a finite list of interpolation functions. We've collected the easing functions in a visual document here

https://zeffii.github.io/docs_easing_node/

- (screenshot, open in new tab to show all)

|visual_easing|

the original development thread is here:
https://github.com/nortikin/sverchok/issues/695

You can see the kind of easing curve because we draw it to the right of the node.
Add the node to the tree and connect something useful to the input, and scroll through the list of easing curve types.

|visual_viewport|


.. |visual_easing| image:: https://user-images.githubusercontent.com/619340/82451459-51779580-9aae-11ea-9dce-9a4dc1236014.png
.. |visual_viewport| image:: https://user-images.githubusercontent.com/619340/111627552-76808600-87ef-11eb-9929-f9295d766623.png
