slice lite
==========

This node differs little from the current slice node, but it does use alternative code. If the regular node isn't doing what you expect, it's worth trying this one.

.. image:: https://user-images.githubusercontent.com/619340/27024302-5a5a93a6-4f56-11e7-81fe-7b46ebbde185.png


https://github.com/nortikin/sverchok/issues/1656