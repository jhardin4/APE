Armature Props
==========

Functionality
-------------



Examples of usage
-----------------

.. image:: https://user-images.githubusercontent.com/22656834/38471846-63b7e26a-3b90-11e8-80dd-1023aef5c80f.png
.. image:: https://user-images.githubusercontent.com/22656834/38472081-f207f2e6-3b93-11e8-81bf-0413daadedda.png
.. image:: https://user-images.githubusercontent.com/22656834/38483446-5be69746-3bec-11e8-96a3-0f24295fd6c6.png
