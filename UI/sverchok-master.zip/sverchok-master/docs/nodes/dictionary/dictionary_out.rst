Dictionary out
==============

.. image:: https://user-images.githubusercontent.com/28003269/71804968-6a8f2500-307e-11ea-85ce-8c3c7619ee0a.png

Functionality
-------------

The node unpacks dictionary and assign values of each key to sockets with names of keys.

Category
--------

Dictionary -> dictionary out

Inputs
------

- **Dict** - dictionary(ies)

Outputs
-------

According keys of input dictionary. If multiple dictionary are given only keys of first dictionary are taken in account.

Examples
--------

.. image:: https://user-images.githubusercontent.com/28003269/71805215-218ba080-307f-11ea-8321-1886a62837c5.png