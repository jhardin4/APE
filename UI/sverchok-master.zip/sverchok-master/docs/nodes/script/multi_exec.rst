multi exec
==========

This node allows you to write short scripts inside the node UI. This node deserves a good set of explanations and examples.

The node development threads give some idea on usecases:

https://github.com/nortikin/sverchok/issues/1056

features
========

- load script from text editor
- add lines / removes lines / rearrange lines
