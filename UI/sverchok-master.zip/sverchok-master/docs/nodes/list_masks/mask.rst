List Mask Out
=============