Flip Curve
==========

Functionality
-------------

This node generates a curve by inverting the direciton of parametrization of another curve; in other words, it generates the curve identical to provided one, but with the opposite direction.

Inputs
------

This node has the following input:

* **Curve**. The curve to be flipped. This input is mandatory.

Outputs
-------

This node has the following output:

* **Curve**. The flipped curve.

