Mirror Solid
============

Functionality
-------------

Performs symmetry of a solid along defined plane.

The symmetry plane is defined by a matrix




Examples
--------

.. image:: https://raw.githubusercontent.com/vicdoval/sverchok/docs_images/images_for_docs/solid/mirror_solid/mirror_solid_blender_sverchok_example.png
