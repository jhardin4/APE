*****
Solid
*****

.. toctree::
   :maxdepth: 2

   box_solid
   cone_solid
   cylinder_solid
   sphere_solid
   torus_solid
   polygon_face
   wire_face
   projection_trim_face
   transform_solid
   chamfer_solid
   fillet_solid
   solid_boolean
   general_fuse
   mirror_solid
   offset_solid
   solid_from_faces
   ruled_solid
   extrude_face
   solidify_face
   revolve_face
   sweep_face
   split_solid
   points_inside_solid
   solid_distance
   slice_solid
   hollow_solid
   mesh_to_solid
   solid_to_mesh_mk2
   solid_faces
   solid_edges
   solid_vertices
   solid_select
   import_solid
   export_solid
   face_area
   area
   volume
   center_of_mass
   is_closed
   refine
   validate
   bound_box
   make_compound
   solid_viewer

